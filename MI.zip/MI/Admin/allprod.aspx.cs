﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_allprod : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowDeleting1(object sender, GridViewDeleteEventArgs e)
    {

        Label productid = GridView1.Rows[e.RowIndex].FindControl("Label7") as Label;

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\project\MI\MI\App_Data\Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "delete from product where pid='" + productid.Text + "'";
        cmd.ExecuteNonQuery();
        Label6.Text = "Row Data Deleted SuccessFully";
        GridView1.EditIndex = -1;
        SqlDataSource1.DataBind();
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
    }
    protected void GridView1_RowEditing1(object sender, GridViewEditEventArgs e)
    {

        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
        Label6.Text = "";
        GridView1.EditRowStyle.BackColor = System.Drawing.Color.Orange;
    }
    protected void GridView1_RowUpdating1(object sender, GridViewUpdateEventArgs e)
    {

        Label productid = GridView1.Rows[e.RowIndex].FindControl("Label11") as Label;
        TextBox productname = GridView1.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;
        TextBox productprice = GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;
        String mycon = (@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\project\MI\MI\App_Data\Database.mdf;Integrated Security=True;User Instance=True");
        String updata = "update product set pname='" + productname.Text + "',price='" + productprice.Text + "' where pid='" + productid.Text + "'";
        SqlConnection con = new SqlConnection(mycon);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updata;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        Label6.Text = "Row Data Has Been Updated Successfully";
        GridView1.EditIndex = -1;
        SqlDataSource1.DataBind();
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
    }
    protected void GridView1_RowCancelingEdit1(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
        Label6.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Adminhome.aspx");
    }
}